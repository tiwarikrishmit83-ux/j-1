# JEEVAN SETHU — Production Web App

## Stack
- Node.js 20+
- Express
- PostgreSQL
- Secure server-side sessions stored in PostgreSQL
- bcrypt password hashing
- Helmet security headers
- Login rate limiting

## Required production variables
`NODE_ENV`, `PORT`, `DATABASE_URL`, `SESSION_SECRET`, `OWNER_NAME`, `OWNER_EMAIL`, `OWNER_PASSWORD`. The requested initial Owner/Admin password is `1234`; change it before public launch.

## Run locally
1. Install Node.js 20+.
2. Create a PostgreSQL database.
3. Copy `.env.example` to `.env` and fill every value.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

The server creates the required PostgreSQL tables on first startup and seeds the owner account if the configured owner email does not already exist.

## Production deployment
Railway can deploy the Node service and PostgreSQL in one project. Add PostgreSQL first, set the app's `DATABASE_URL` to the PostgreSQL service reference, add the other secrets, then deploy the Node service. Generate a public domain and attach the custom domain in the hosting dashboard.

Never commit `.env` or real passwords/secrets to Git.


## Admin Daily Payments
The Owner/Admin dashboard includes date-wise payment tracking with paid, pending and refunded totals, customer/service details, payment method, status updates and deletion. Payments are stored in PostgreSQL.

## Online payments
The app now supports Razorpay online payments. Set `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` in production environment variables. Never commit the secret. The server creates Razorpay Orders and verifies the checkout signature before marking the payment as Paid.


### Payment methods
Cash and Wallet are supported in Owner payment records, alongside online methods. Wallet here is recorded as a payment method; a separate stored-value wallet/auto top-up system requires a customer wallet account and payment-gateway top-up flow.


## Admin accounts
The production app creates 10 operational admin accounts automatically: Admin 1 through Admin 10. Their shared initial password is controlled by `ADMIN_PASSWORD` and defaults to `1234`. Owner remains Tiwari Amit. Owner-only Settings and Payments & Reports remain restricted to the Owner.
