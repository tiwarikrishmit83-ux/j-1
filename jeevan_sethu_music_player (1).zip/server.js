require('dotenv').config();
const express = require('express');
const session = require('express-session');
const pgSession = require('connect-pg-simple')(session);
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const crypto = require('crypto');
const { OAuth2Client } = require('google-auth-library');
const path = require('path');

const app = express();
const isProd = process.env.NODE_ENV === 'production';
const port = Number(process.env.PORT || 3000);
const googleClientId = String(process.env.GOOGLE_CLIENT_ID || '').trim();
const googleClient = googleClientId ? new OAuth2Client(googleClientId) : null;

if (isProd && !process.env.SESSION_SECRET) {
  throw new Error('SESSION_SECRET is required in production');
}
if (!process.env.DATABASE_URL) {
  throw new Error('DATABASE_URL is required');
}
if (!process.env.OWNER_PASSWORD) {
  throw new Error('OWNER_PASSWORD is required');
}
if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
  console.warn('Razorpay live/test keys are not configured; online payments will be unavailable.');
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: isProd ? { rejectUnauthorized: false } : undefined,
  max: 10,
  idleTimeoutMillis: 30000
});

app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  store: new pgSession({ pool, tableName: 'user_sessions', createTableIfMissing: true }),
  secret: process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex'),
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: isProd,
    sameSite: 'lax',
    maxAge: 1000 * 60 * 60 * 12
  }
}));
app.use(express.static(path.join(__dirname)));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many login attempts. Please try again later.' }
});

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS admins (
      id UUID PRIMARY KEY,
      name TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS owners (
      id UUID PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS google_users (
      id UUID PRIMARY KEY,
      google_sub TEXT UNIQUE NOT NULL,
      email TEXT NOT NULL,
      name TEXT NOT NULL,
      picture TEXT NOT NULL DEFAULT '',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      last_login_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS owner_settings (
      owner_id UUID PRIMARY KEY REFERENCES owners(id) ON DELETE CASCADE,
      contact_email TEXT NOT NULL DEFAULT 'jeevansethuhelp@jeevansetu.in',
      contact_phone TEXT NOT NULL DEFAULT '+91 84694 63623',
      notifications_enabled BOOLEAN NOT NULL DEFAULT TRUE,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS entries (
      id UUID PRIMARY KEY,
      name TEXT NOT NULL,
      phone TEXT NOT NULL DEFAULT '',
      purpose TEXT NOT NULL DEFAULT '',
      entry_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      exit_at TIMESTAMPTZ,
      status TEXT NOT NULL DEFAULT 'Inside' CHECK (status IN ('Inside','Exited')),
      created_by UUID REFERENCES owners(id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS service_requests (
      id TEXT PRIMARY KEY,
      service TEXT NOT NULL DEFAULT '',
      note TEXT NOT NULL DEFAULT '',
      customer_name TEXT NOT NULL DEFAULT '',
      phone TEXT NOT NULL DEFAULT '',
      address TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending','Accepted','Rejected','Completed')),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      accepted_at TIMESTAMPTZ
    );
    CREATE INDEX IF NOT EXISTS service_requests_created_at_idx ON service_requests(created_at);

    CREATE TABLE IF NOT EXISTS payments (
      id UUID PRIMARY KEY,
      customer_name TEXT NOT NULL,
      phone TEXT NOT NULL DEFAULT '',
      service TEXT NOT NULL DEFAULT '',
      amount NUMERIC(12,2) NOT NULL CHECK (amount >= 0),
      method TEXT NOT NULL DEFAULT 'Cash' CHECK (method IN ('Cash','Wallet','UPI','Card','Bank Transfer','Other')),
      status TEXT NOT NULL DEFAULT 'Paid' CHECK (status IN ('Paid','Pending','Refunded')),
      payment_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      notes TEXT NOT NULL DEFAULT '',
      gateway TEXT,
      gateway_order_id TEXT UNIQUE,
      gateway_payment_id TEXT UNIQUE,
      created_by UUID REFERENCES owners(id) ON DELETE SET NULL
    );
    CREATE INDEX IF NOT EXISTS payments_payment_at_idx ON payments(payment_at);
    ALTER TABLE payments ADD COLUMN IF NOT EXISTS gateway TEXT;
    ALTER TABLE payments ADD COLUMN IF NOT EXISTS gateway_order_id TEXT UNIQUE;
    ALTER TABLE payments ADD COLUMN IF NOT EXISTS gateway_payment_id TEXT UNIQUE;
    ALTER TABLE payments DROP CONSTRAINT IF EXISTS payments_method_check;
    ALTER TABLE payments ADD CONSTRAINT payments_method_check CHECK (method IN ('Cash','Wallet','UPI','Card','Bank Transfer','Other','Razorpay'));
  `);

  const email = (process.env.OWNER_EMAIL || 'jeevansethuhelp@jeevansetu.in').trim().toLowerCase();
  const name = (process.env.OWNER_NAME || 'Tiwari Amit').trim();
  await pool.query('DELETE FROM owners WHERE lower(email)<>lower($1) OR lower(name)<>lower($2)', [email, name]);
  const existing = await pool.query('SELECT id FROM owners WHERE email=$1 AND lower(name)=lower($2) LIMIT 1', [email, name]);
  let ownerId;
  if (!existing.rowCount) {
    const hash = await bcrypt.hash(process.env.OWNER_PASSWORD, 12);
    ownerId = crypto.randomUUID();
    await pool.query('INSERT INTO owners(id,name,email,password_hash) VALUES($1,$2,$3,$4)', [ownerId, name, email, hash]);
  } else {
    ownerId = existing.rows[0].id;
    // Keep the configured production Owner password in sync with the environment.
    const hash = await bcrypt.hash(process.env.OWNER_PASSWORD, 12);
    await pool.query('UPDATE owners SET password_hash=$1 WHERE id=$2', [hash, ownerId]);
  }
  await pool.query(`INSERT INTO owner_settings(owner_id,contact_email,contact_phone) VALUES($1,$2,$3) ON CONFLICT (owner_id) DO NOTHING`, [ownerId, email, process.env.OWNER_PHONE || '+91 84694 63623']);

  const adminPassword = process.env.ADMIN_PASSWORD || '1234';
  const adminHash = await bcrypt.hash(adminPassword, 12);
  for (let i = 1; i <= 10; i++) {
    const adminName = `Admin ${i}`;
    await pool.query(
      `INSERT INTO admins(id,name,password_hash) VALUES($1,$2,$3)
       ON CONFLICT (name) DO UPDATE SET password_hash=EXCLUDED.password_hash`,
      [crypto.randomUUID(), adminName, adminHash]
    );
  }
}

async function auth(req, res, next) {
  if (req.session.ownerId) {
    const ownerEmail = (process.env.OWNER_EMAIL || 'jeevansethuhelp@jeevansetu.in').trim().toLowerCase();
    const ownerName = (process.env.OWNER_NAME || 'Tiwari Amit').trim();
    const r = await pool.query('SELECT id,name,email FROM owners WHERE id=$1 AND lower(email)=lower($2) AND lower(name)=lower($3)', [req.session.ownerId, ownerEmail, ownerName]);
    if (r.rowCount) { req.owner = r.rows[0]; req.user = { id:r.rows[0].id, name:r.rows[0].name, role:'owner', email:r.rows[0].email }; return next(); }
  }
  if (req.session.adminId) {
    const r = await pool.query('SELECT id,name FROM admins WHERE id=$1', [req.session.adminId]);
    if (r.rowCount) { req.admin = r.rows[0]; req.user = { id:r.rows[0].id, name:r.rows[0].name, role:'admin' }; return next(); }
  }
  return res.status(401).json({ error: 'Please login again.' });
}

async function ownerAuth(req, res, next) {
  if (req.user?.role !== 'owner') return res.status(403).json({ error: 'Owner-only access.' });
  next();
}

app.get('/health', async (req, res) => {
  try { await pool.query('SELECT 1'); res.json({ ok: true, service: 'jeevan-sethu' }); }
  catch { res.status(503).json({ ok: false }); }
});

app.post('/api/login', loginLimiter, async (req, res) => {
  try {
    const name = String(req.body?.name || '').trim();
    const password = String(req.body?.password || '');
    const ownerName = (process.env.OWNER_NAME || 'Tiwari Amit').trim();
    const ownerEmail = (process.env.OWNER_EMAIL || 'jeevansethuhelp@jeevansetu.in').trim().toLowerCase();
    const owner = await pool.query('SELECT id,name,email,password_hash FROM owners WHERE lower(name)=lower($1) AND lower(email)=lower($2) LIMIT 1', [ownerName, ownerEmail]);
    if (owner.rowCount && await bcrypt.compare(password, owner.rows[0].password_hash)) {
      req.session.ownerId = owner.rows[0].id;
      req.session.adminId = null;
      return res.json({ user: owner.rows[0].name, role: 'owner' });
    }
    const admin = await pool.query('SELECT id,name,password_hash FROM admins WHERE lower(name)=lower($1) LIMIT 1', [name]);
    if (admin.rowCount && await bcrypt.compare(password, admin.rows[0].password_hash)) {
      req.session.adminId = admin.rows[0].id;
      req.session.ownerId = null;
      return res.json({ user: admin.rows[0].name, role: 'admin' });
    }
    return res.status(401).json({ error: 'Invalid Owner/Admin credentials.' });
  } catch (e) { res.status(500).json({ error: 'Login failed.' }); }
});

app.get('/api/auth/google/config', (req, res) => {
  res.json({ enabled: Boolean(googleClientId), client_id: googleClientId || null });
});

app.post('/api/auth/google', loginLimiter, async (req, res) => {
  try {
    if (!googleClient) return res.status(503).json({ error: 'Google Sign-In is not configured yet. Add GOOGLE_CLIENT_ID to the production environment.' });
    const credential = String(req.body?.credential || '').trim();
    if (!credential) return res.status(400).json({ error: 'Google credential is required.' });
    const ticket = await googleClient.verifyIdToken({ idToken: credential, audience: googleClientId });
    const payload = ticket.getPayload();
    if (!payload?.sub || !payload?.email) return res.status(401).json({ error: 'Invalid Google account token.' });
    const googleSub = String(payload.sub);
    const email = String(payload.email).trim().toLowerCase();
    const name = String(payload.name || email.split('@')[0]).trim().slice(0, 160);
    const picture = String(payload.picture || '').trim().slice(0, 1000);
    const r = await pool.query(`INSERT INTO google_users(id,google_sub,email,name,picture,last_login_at)
      VALUES($1,$2,$3,$4,$5,NOW())
      ON CONFLICT (google_sub) DO UPDATE SET email=EXCLUDED.email,name=EXCLUDED.name,picture=EXCLUDED.picture,last_login_at=NOW()
      RETURNING id,email,name,picture`, [crypto.randomUUID(), googleSub, email, name, picture]);
    const user = r.rows[0];
    req.session.googleUserId = user.id;
    req.session.ownerId = null;
    req.session.adminId = null;
    return res.json({ user: user.name, email: user.email, picture: user.picture, role: 'customer' });
  } catch (e) {
    console.error('Google login failed:', e.message);
    return res.status(401).json({ error: 'Google Sign-In verification failed.' });
  }
});

app.post('/api/logout', (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get('/api/me', async (req, res) => {
  if (req.session.ownerId) {
    const r = await pool.query('SELECT name FROM owners WHERE id=$1', [req.session.ownerId]);
    if (r.rowCount) return res.json({ user: r.rows[0].name, owner: r.rows[0].name, role: 'owner' });
  }
  if (req.session.adminId) {
    const r = await pool.query('SELECT name FROM admins WHERE id=$1', [req.session.adminId]);
    if (r.rowCount) return res.json({ user: r.rows[0].name, owner: r.rows[0].name, role: 'admin' });
  }
  if (req.session.googleUserId) {
    const r = await pool.query('SELECT name,email,picture FROM google_users WHERE id=$1', [req.session.googleUserId]);
    if (r.rowCount) return res.json({ user: r.rows[0].name, email: r.rows[0].email, picture: r.rows[0].picture, role: 'customer' });
  }
  res.json({ user: null, owner: null, role: null });
});

app.get('/api/settings', auth, ownerAuth, async (req, res) => {
  const r = await pool.query('SELECT contact_email, contact_phone, notifications_enabled, updated_at FROM owner_settings WHERE owner_id=$1', [req.owner.id]);
  const s = r.rows[0] || {contact_email: process.env.OWNER_EMAIL || 'jeevansethuhelp@jeevansetu.in', contact_phone: process.env.OWNER_PHONE || '+91 84694 63623', notifications_enabled: true};
  res.json({ settings: s, owner: { name: req.owner.name, email: req.owner.email } });
});

app.patch('/api/settings', auth, ownerAuth, async (req, res) => {
  const contactEmail = String(req.body?.contact_email || '').trim().toLowerCase();
  const contactPhone = String(req.body?.contact_phone || '').trim();
  const notifications = req.body?.notifications_enabled !== false;
  if (!/^\S+@\S+\.\S+$/.test(contactEmail)) return res.status(400).json({error:'Valid contact email required'});
  if (!contactPhone) return res.status(400).json({error:'Contact phone required'});
  await pool.query(`INSERT INTO owner_settings(owner_id,contact_email,contact_phone,notifications_enabled,updated_at) VALUES($1,$2,$3,$4,NOW()) ON CONFLICT(owner_id) DO UPDATE SET contact_email=EXCLUDED.contact_email,contact_phone=EXCLUDED.contact_phone,notifications_enabled=EXCLUDED.notifications_enabled,updated_at=NOW()`, [req.owner.id,contactEmail,contactPhone,notifications]);
  res.json({ok:true});
});

app.patch('/api/settings/password', auth, ownerAuth, async (req, res) => {
  const current = String(req.body?.current_password || '');
  const next = String(req.body?.new_password || '');
  if (next.length < 8) return res.status(400).json({error:'New password must be at least 8 characters.'});
  const r = await pool.query('SELECT password_hash FROM owners WHERE id=$1', [req.owner.id]);
  if (!r.rowCount || !(await bcrypt.compare(current, r.rows[0].password_hash))) return res.status(400).json({error:'Current password is incorrect.'});
  const hash = await bcrypt.hash(next, 12);
  await pool.query('UPDATE owners SET password_hash=$1 WHERE id=$2', [hash, req.owner.id]);
  res.json({ok:true});
});

app.get('/api/entries', auth, async (req, res) => {
  const r = await pool.query(`SELECT id,name,phone,purpose,
    to_char(entry_at AT TIME ZONE 'Asia/Kolkata','DD Mon YYYY, HH24:MI') AS entry_at,
    CASE WHEN exit_at IS NULL THEN '' ELSE to_char(exit_at AT TIME ZONE 'Asia/Kolkata','DD Mon YYYY, HH24:MI') END AS exit_at,
    status FROM entries ORDER BY entry_at DESC`);
  res.json({ entries: r.rows });
});

app.post('/api/entries', auth, async (req, res) => {
  const name = String(req.body?.name || '').trim().slice(0, 120);
  const phone = String(req.body?.phone || '').trim().slice(0, 30);
  const purpose = String(req.body?.purpose || '').trim().slice(0, 200);
  if (!name) return res.status(400).json({ error: 'Name required' });
  const id = crypto.randomUUID();
  await pool.query('INSERT INTO entries(id,name,phone,purpose,created_by) VALUES($1,$2,$3,$4,$5)', [id,name,phone,purpose,req.owner.id]);
  res.status(201).json({ ok: true, id });
});

app.patch('/api/entries', auth, async (req, res) => {
  if (req.body?.action !== 'exit') return res.status(400).json({ error: 'Unsupported action' });
  const r = await pool.query("UPDATE entries SET status='Exited', exit_at=NOW() WHERE id=$1 AND status='Inside' RETURNING id", [req.body.id]);
  if (!r.rowCount) return res.status(404).json({ error: 'Entry not found or already exited' });
  res.json({ ok: true });
});

app.delete('/api/entries', auth, async (req, res) => {
  const r = await pool.query('DELETE FROM entries WHERE id=$1 RETURNING id', [req.body?.id]);
  if (!r.rowCount) return res.status(404).json({ error: 'Entry not found' });
  res.json({ ok: true });
});

app.post('/api/online-payment/order', async (req, res) => {
  try {
    if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) return res.status(503).json({ error: 'Online payment is not configured yet.' });
    const customerName=String(req.body?.customer_name||'').trim().slice(0,120);
    const phone=String(req.body?.phone||'').trim().slice(0,30);
    const service=String(req.body?.service||'Roadside Assistance').trim().slice(0,120);
    const amount=Number(req.body?.amount);
    if(!customerName || !phone || !Number.isFinite(amount) || amount < 1) return res.status(400).json({error:'Name, phone and valid amount are required'});
    const receipt='JS-'+Date.now()+'-'+crypto.randomBytes(4).toString('hex');
    const authHeader=Buffer.from(process.env.RAZORPAY_KEY_ID+':'+process.env.RAZORPAY_KEY_SECRET).toString('base64');
    const rr=await fetch('https://api.razorpay.com/v1/orders',{method:'POST',headers:{Authorization:'Basic '+authHeader,'Content-Type':'application/json'},body:JSON.stringify({amount:Math.round(amount*100),currency:'INR',receipt,notes:{customer_name:customerName,phone,service}})});
    const order=await rr.json();
    if(!rr.ok) return res.status(502).json({error:'Payment gateway order creation failed'});
    const id=crypto.randomUUID();
    await pool.query('INSERT INTO payments(id,customer_name,phone,service,amount,method,status,notes,gateway,gateway_order_id) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',[id,customerName,phone,service,amount,'Razorpay','Pending','Online payment order', 'Razorpay',order.id]);
    res.json({key_id:process.env.RAZORPAY_KEY_ID,order_id:order.id,amount:order.amount,currency:order.currency,customer_name:customerName,phone,service});
  } catch(e){ res.status(500).json({error:'Unable to start online payment'}); }
});

app.post('/api/online-payment/verify', async (req, res) => {
  try {
    const orderId=String(req.body?.razorpay_order_id||''); const paymentId=String(req.body?.razorpay_payment_id||''); const signature=String(req.body?.razorpay_signature||'');
    if(!orderId||!paymentId||!signature) return res.status(400).json({error:'Incomplete payment verification data'});
    const expected=crypto.createHmac('sha256',process.env.RAZORPAY_KEY_SECRET).update(orderId+'|'+paymentId).digest('hex');
    if(!crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(signature))) return res.status(400).json({error:'Payment signature verification failed'});
    const r=await pool.query("UPDATE payments SET status='Paid',method='Razorpay',gateway_payment_id=$1,notes='Online payment verified' WHERE gateway_order_id=$2 RETURNING id,amount",[paymentId,orderId]);
    if(!r.rowCount) return res.status(404).json({error:'Payment order not found'});
    res.json({ok:true,payment_id:paymentId});
  } catch(e){ res.status(500).json({error:'Payment verification failed'}); }
});

app.post('/api/service-requests', async (req,res)=>{
  try{
    const id=crypto.randomUUID();
    const service=String(req.body?.service||'').trim().slice(0,100);
    const note=String(req.body?.note||'').trim().slice(0,500);
    const customerName=String(req.body?.customer_name||'').trim().slice(0,120);
    const phone=String(req.body?.phone||'').trim().slice(0,30);
    const address=String(req.body?.address||'').trim().slice(0,300);
    if(!service||!customerName||!phone) return res.status(400).json({error:'Service, name and phone are required'});
    await pool.query('INSERT INTO service_requests(id,service,note,customer_name,phone,address) VALUES($1,$2,$3,$4,$5,$6)',[id,service,note,customerName,phone,address]);
    res.status(201).json({ok:true,request_id:id,status:'Pending'});
  }catch(e){res.status(500).json({error:'Unable to create request'});}
});

app.get('/api/service-requests', auth, async (req,res)=>{
  const r=await pool.query(`SELECT id,service,note,status,
    to_char(created_at AT TIME ZONE 'Asia/Kolkata','DD Mon YYYY, HH24:MI') AS created_at,
    CASE WHEN status='Accepted' THEN true ELSE false END AS accepted
    FROM service_requests ORDER BY created_at DESC`);
  // Personal identity/contact fields intentionally excluded from the Owner response.
  res.json({requests:r.rows});
});

app.patch('/api/service-requests/:id', auth, async (req,res)=>{
  const status=String(req.body?.status||'');
  if(!['Accepted','Rejected','Completed'].includes(status)) return res.status(400).json({error:'Invalid request status'});
  const r=await pool.query(`UPDATE service_requests SET status=$1, accepted_at=CASE WHEN $1='Accepted' THEN NOW() ELSE accepted_at END WHERE id=$2 RETURNING id,status`,[status,req.params.id]);
  if(!r.rowCount) return res.status(404).json({error:'Request not found'});
  res.json(r.rows[0]);
});

app.get('/api/payments', auth, ownerAuth, async (req, res) => {
  const date = String(req.query.date || '').trim();
  const month = String(req.query.month || '').trim();
  const year = String(req.query.year || '').trim();
  const params = [];
  let where = '';
  if (/^\d{4}-\d{2}$/.test(month)) {
    params.push(month + '-01');
    where = `WHERE payment_at >= ($1::date AT TIME ZONE 'Asia/Kolkata')
             AND payment_at < (($1::date + INTERVAL '1 month') AT TIME ZONE 'Asia/Kolkata')`;
  } else if (/^\d{4}$/.test(year)) {
    params.push(year + '-01-01');
    where = `WHERE payment_at >= ($1::date AT TIME ZONE 'Asia/Kolkata')
             AND payment_at < (($1::date + INTERVAL '1 year') AT TIME ZONE 'Asia/Kolkata')`;
  } else if (/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    params.push(date);
    where = `WHERE payment_at >= ($1::date AT TIME ZONE 'Asia/Kolkata')
             AND payment_at < (($1::date + INTERVAL '1 day') AT TIME ZONE 'Asia/Kolkata')`;
  }
  const r = await pool.query(`SELECT id,customer_name,phone,service,amount::numeric::float8 AS amount,method,status,
    to_char(payment_at AT TIME ZONE 'Asia/Kolkata','DD Mon YYYY, HH24:MI') AS payment_at, notes
    FROM payments ${where} ORDER BY payment_at DESC`, params);
  const summary = await pool.query(`SELECT
    COALESCE(SUM(CASE WHEN status='Paid' THEN amount ELSE 0 END),0)::numeric::float8 AS paid,
    COALESCE(SUM(CASE WHEN status='Pending' THEN amount ELSE 0 END),0)::numeric::float8 AS pending,
    COALESCE(SUM(CASE WHEN status='Refunded' THEN amount ELSE 0 END),0)::numeric::float8 AS refunded,
    COUNT(*)::int AS count FROM payments ${where}`, params);
  res.json({ payments:r.rows, summary:summary.rows[0] });
});

app.post('/api/payments', auth, ownerAuth, async (req, res) => {
  const customerName=String(req.body?.customer_name||'').trim().slice(0,120);
  const phone=String(req.body?.phone||'').trim().slice(0,30);
  const service=String(req.body?.service||'').trim().slice(0,120);
  const amount=Number(req.body?.amount);
  const method=String(req.body?.method||'Cash');
  const status=String(req.body?.status||'Paid');
  const notes=String(req.body?.notes||'').trim().slice(0,300);
  if(!customerName) return res.status(400).json({error:'Customer name required'});
  if(!Number.isFinite(amount)||amount<0) return res.status(400).json({error:'Valid payment amount required'});
  if(!['Cash','Wallet','UPI','Card','Bank Transfer','Other','Razorpay'].includes(method)) return res.status(400).json({error:'Invalid payment method'});
  if(!['Paid','Pending','Refunded'].includes(status)) return res.status(400).json({error:'Invalid payment status'});
  const id=crypto.randomUUID();
  await pool.query('INSERT INTO payments(id,customer_name,phone,service,amount,method,status,notes,created_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)',[id,customerName,phone,service,amount,method,status,notes,req.owner.id]);
  res.status(201).json({ok:true,id});
});

app.patch('/api/payments', auth, ownerAuth, async (req, res) => {
  const id=String(req.body?.id||'');
  const status=String(req.body?.status||'');
  if(!['Paid','Pending','Refunded'].includes(status)) return res.status(400).json({error:'Invalid payment status'});
  const r=await pool.query('UPDATE payments SET status=$1 WHERE id=$2 RETURNING id',[status,id]);
  if(!r.rowCount) return res.status(404).json({error:'Payment not found'});
  res.json({ok:true});
});

app.delete('/api/payments', auth, ownerAuth, async (req, res) => {
  const r=await pool.query('DELETE FROM payments WHERE id=$1 RETURNING id',[req.body?.id]);
  if(!r.rowCount) return res.status(404).json({error:'Payment not found'});
  res.json({ok:true});
});

app.use((err, req, res, next) => { console.error(err); res.status(500).json({ error: 'Server error' }); });

initDb().then(() => app.listen(port, '0.0.0.0', () => console.log(`Jeevan Sethu listening on ${port}`)))
  .catch(err => { console.error('Startup failed:', err); process.exit(1); });
